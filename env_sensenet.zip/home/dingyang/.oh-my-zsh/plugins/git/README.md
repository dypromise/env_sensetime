## git

**Maintainer:** [@ncanceill](https://github.com/ncanceill)

This plugin adds many useful aliases and functions.

### Usage

See the [wiki](https://github.com/robbyrussell/oh-my-zsh/wiki/Plugin:git) for a list of aliases and functions provided by the plugin.

