#!zsh
alias artisan='php artisan'
alias bob='php artisan bob::build'
